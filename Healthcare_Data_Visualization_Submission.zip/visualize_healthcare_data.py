# Reproducible analysis for Virtual Works Lab Task 2
# Requirements: pandas, matplotlib, openpyxl
# Run from the folder containing healthcare_patient_dataset_task1.csv

import os
import pandas as pd
import matplotlib.pyplot as plt

INPUT = "healthcare_patient_dataset_task1.csv"
OUT = "charts"
os.makedirs(OUT, exist_ok=True)
df = pd.read_csv(INPUT)
for c in ["Gender", "Disease", "Medication"]:
    if c in df:
        df[c] = df[c].astype("string").str.strip().replace({"": pd.NA, "nan": pd.NA, "None": pd.NA})
for c in ["Age", "Dosage_mg"]:
    if c in df:
        df[c] = pd.to_numeric(df[c], errors="coerce")
df = df.drop_duplicates()
if "Age" in df and df["Age"].notna().any():
    df["Age"] = df["Age"].fillna(df["Age"].median())
if "Medication" in df and df["Medication"].notna().any():
    df["Medication"] = df["Medication"].fillna(df["Medication"].mode().iloc[0])
for c in ["Gender", "Disease"]:
    if c in df:
        df[c] = df[c].fillna("Unknown")
if "Age" in df:
    df["Age_Group"] = pd.cut(df["Age"], bins=[-1,18,35,50,65,float("inf")],
                             labels=["0–18","19–35","36–50","51–65","66+"], include_lowest=True)
plots = [
    ("patients_by_disease", "Disease"),
    ("patients_by_gender", "Gender"),
    ("medication_usage", "Medication"),
    ("patients_by_age_group", "Age_Group"),
]
for filename, col in plots:
    if col not in df:
        continue
    counts = df[col].value_counts().sort_index()
    fig, ax = plt.subplots(figsize=(8,5))
    counts.plot(kind="bar", ax=ax)
    ax.set_title(filename.replace("_", " ").title())
    ax.set_ylabel("Number of records")
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, filename + ".png"), dpi=160)
    plt.close(fig)
df.to_csv("healthcare_patient_dataset_cleaned.csv", index=False)
print("Analysis completed. Charts are in:", OUT)
