# Healthcare Data Visualization — Virtual Works Lab Task 2

## Objective
Create visual representations of healthcare data using charts and graphs to understand disease distribution, age distribution, gender ratio, and medication usage.

## Contents
- `Healthcare_Data_Visualization_Dashboard.xlsx`: Excel dashboard, editable charts, key metrics, cleaned data, and chart data.
- `healthcare_patient_dataset_cleaned.csv`: cleaned dataset used for visualization.
- `healthcare_patient_dataset_task1.csv`: original input dataset.
- `charts/`: PNG chart images.
- `visualize_healthcare_data.py`: reproducible Python analysis script.

## Data cleaning
- Original records: 102
- Exact duplicate rows removed: 2
- Records after duplicate removal: 100
- Missing age values filled using the median: 1
- Missing medication values filled using the mode: 1
- Text fields trimmed; age groups created for charts.

## Key findings
- Average age: 47.9 years
- Most common disease: Common Cold
- Most common medication: Paracetamol

## How to submit
Extract this ZIP file and upload its contents (including the `charts` folder) into a public GitHub repository. Do not upload only the Excel file, because the task asks for multiple visualizations and supporting files.

## Note
This is a student data-visualization exercise. Findings describe only the supplied dataset and should not be treated as real-world clinical evidence.
